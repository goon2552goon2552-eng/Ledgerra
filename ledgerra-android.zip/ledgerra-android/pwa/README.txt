Ledgerra PWA - วิธีขึ้นออนไลน์ฟรี (ไม่ต้องสมัคร App Store)
1) สมัคร Netlify หรือ Cloudflare Pages (ฟรี) แล้วลากโฟลเดอร์ ledgerra-pwa นี้ไปวาง (Netlify: app.netlify.com/drop)
2) เปิดลิงก์ที่ได้ด้วย Safari (iPhone/iPad) หรือ Chrome (Android)
3) iOS: แชร์ > เพิ่มลงในหน้าจอโฮม | Android: เมนู > ติดตั้งแอป
หมายเหตุ: ต้องเป็นลิงก์ https ข้อมูลเก็บในเครื่อง ไม่ซิงก์ข้ามเครื่อง
