// Builds dist/pwa = the folder for Netlify (iPhone/iPad), from the same src/ledgerra.html as the APK.
// Adds the web manifest, the home-screen icon and the service worker, and raises the cache
// version so installed copies pick up the update.
import { readFileSync, writeFileSync, mkdirSync, rmSync, cpSync } from 'node:fs';

const OUT = 'dist/pwa';
const TAIL = "authUI('in');opening();nativeInit();\n</script></body></html>";
let html = readFileSync('src/ledgerra.html', 'utf8');
if (!html.includes(TAIL)) throw new Error('unexpected end of src/ledgerra.html');

// manifest, home-screen icons and the iOS launch images (one per iPhone/iPad size)
html = html.replace('</title>', '</title>' + readFileSync('scripts/pwa-head.html', 'utf8').trim());
html = html.replace(TAIL, "authUI('in');opening();nativeInit();\nif('serviceWorker' in navigator)addEventListener('load',()=>navigator.serviceWorker.register('sw.js').catch(()=>{}));\n</script></body></html>");

let sw = readFileSync('pwa/sw.js', 'utf8');
const n = +((sw.match(/ledgerra-v(\d+)/) || [])[1] || 0) + 1;
sw = sw.replace(/ledgerra-v\d+/g, 'ledgerra-v' + n);
writeFileSync('pwa/sw.js', sw);

rmSync(OUT, { recursive: true, force: true });
mkdirSync(OUT, { recursive: true });
cpSync('pwa', OUT, { recursive: true });
writeFileSync(OUT + '/index.html', html);
console.log(`dist/pwa ready (cache ledgerra-v${n}); drag this folder onto Netlify Drop`);
