// Builds www/ = the files packed inside the APK, from src/ledgerra.html (the same file the PWA uses).
// With internet: also packs the font and the slip reader, so the app works fully offline and,
// once installed, makes no requests to Google Fonts or jsDelivr.
// Without internet: still builds; the app then uses the phone's Thai font and downloads the
// slip reader the first time it is used.
import { readFileSync, writeFileSync, mkdirSync, rmSync } from 'node:fs';

const SRC = 'src/ledgerra.html', OUT = 'www';
const UA = 'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Mobile Safari/537.36';

let html = readFileSync(SRC, 'utf8');
const FONT_LINKS = /<link rel="preconnect" href="https:\/\/fonts\.googleapis\.com">\s*<link href="https:\/\/fonts\.googleapis\.com\/css2\?[^"]+" rel="stylesheet">/;
const fontHref = (html.match(/href="(https:\/\/fonts\.googleapis\.com\/css2\?[^"]+)"/) || [])[1];
if (!FONT_LINKS.test(html) || !fontHref) throw new Error('font links not found in ' + SRC);
if (html.split('</head>').length !== 2) throw new Error('expected exactly one </head> in ' + SRC);

rmSync(OUT, { recursive: true, force: true });
mkdirSync(OUT, { recursive: true });

async function get(url, asText) {
  const r = await fetch(url, { headers: { 'user-agent': UA } });
  if (!r.ok) throw new Error(r.status + ' ' + url);
  return asText ? r.text() : Buffer.from(await r.arrayBuffer());
}

// 1. font: IBM Plex Sans Thai, copied into www/fonts
try {
  mkdirSync(OUT + '/fonts', { recursive: true });
  let css = await get(fontHref.replace(/&amp;/g, '&'), true);
  const urls = [...new Set([...css.matchAll(/url\((https:[^)]+)\)/g)].map(m => m[1]))];
  if (!urls.length) throw new Error('no font files listed');
  let i = 0;
  for (const u of urls) {
    const name = `f${i++}.woff2`;
    writeFileSync(`${OUT}/fonts/${name}`, await get(u));
    css = css.split(u).join(name);
  }
  writeFileSync(`${OUT}/fonts/fonts.css`, css);
  html = html.replace(FONT_LINKS, '<link rel="stylesheet" href="fonts/fonts.css">');
  console.log(`font: packed ${urls.length} files`);
} catch (e) {
  rmSync(OUT + '/fonts', { recursive: true, force: true });
  html = html.replace(FONT_LINKS, '');
  console.warn(`font: not packed (${e.message}); the app will use the phone's Thai font`);
}

// 2. slip reader: Tesseract.js 5 with Thai + English data, copied into www/vendor/tesseract
const CDN = 'https://cdn.jsdelivr.net/npm/', V = OUT + '/vendor/tesseract';
const FILES = [
  ['tesseract.js@5.1.1/dist/tesseract.min.js', 'tesseract.min.js'],
  ['tesseract.js@5.1.1/dist/worker.min.js', 'worker.min.js'],
  ['tesseract.js-core@5/tesseract-core-simd-lstm.wasm.js', 'tesseract-core-simd-lstm.wasm.js'],
  ['tesseract.js-core@5/tesseract-core-lstm.wasm.js', 'tesseract-core-lstm.wasm.js'],
  ['tesseract.js-core@5/tesseract-core-simd.wasm.js', 'tesseract-core-simd.wasm.js'],
  ['tesseract.js-core@5/tesseract-core.wasm.js', 'tesseract-core.wasm.js'],
  ['@tesseract.js-data/tha/4.0.0_best_int/tha.traineddata.gz', 'lang/tha.traineddata.gz'],
  ['@tesseract.js-data/eng/4.0.0_best_int/eng.traineddata.gz', 'lang/eng.traineddata.gz'],
];
try {
  mkdirSync(V + '/lang', { recursive: true });
  for (const [u, n] of FILES) writeFileSync(`${V}/${n}`, await get(CDN + u));
  html = html.replace('</head>', '<script>window.LEDGERRA_OCR_LOCAL=1</script></head>');
  console.log('slip reader: packed');
} catch (e) {
  rmSync(V, { recursive: true, force: true });
  console.warn(`slip reader: not packed (${e.message}); it will download the first time it is used`);
}

writeFileSync(OUT + '/index.html', html);
console.log('www/index.html written (no service worker: the files are inside the APK)');
