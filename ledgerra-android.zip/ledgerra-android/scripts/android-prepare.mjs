// Prepares the Android project: www -> android/, icons + splash, version, privacy settings.
// Run again for every update after raising "version" in package.json (e.g. 1.0.0 -> 1.0.1).
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { execSync } from 'node:child_process';

const run = c => { console.log('> ' + c); execSync(c, { stdio: 'inherit' }); };

run('node scripts/build-www.mjs');
if (!existsSync('android')) run('npx cap add android');
run('npx @capacitor/assets generate --android');

// version: 1.2.3 -> versionCode 10203. It must grow with every update, or Android refuses
// to install the new APK over the old one.
const pkg = JSON.parse(readFileSync('package.json', 'utf8'));
const [a, b, c] = pkg.version.split('.').map(Number);
if ([a, b, c].some(x => !Number.isInteger(x) || x < 0 || x > 99)) throw new Error('version must look like 1.0.0');
const code = a * 10000 + b * 100 + c;
const gradle = 'android/app/build.gradle';
let g = readFileSync(gradle, 'utf8');
if (!/versionCode\s+\d+/.test(g) || !/versionName\s+"[^"]*"/.test(g)) throw new Error('versionCode/versionName not found in ' + gradle);
g = g.replace(/versionCode\s+\d+/, 'versionCode ' + code).replace(/versionName\s+"[^"]*"/, `versionName "${pkg.version}"`);
writeFileSync(gradle, g);

// privacy: Android must not copy the app's data to the cloud backup (Google Drive)
const manifest = 'android/app/src/main/AndroidManifest.xml';
let m = readFileSync(manifest, 'utf8');
m = m.replace(/android:allowBackup="true"/, 'android:allowBackup="false"');
if (!m.includes('android:allowBackup="false"')) throw new Error('could not turn off allowBackup in ' + manifest);
writeFileSync(manifest, m);

run('npx cap sync android');
console.log(`\nready: version ${pkg.version} (versionCode ${code}), app id app.ledgerra, cloud backup off`);
