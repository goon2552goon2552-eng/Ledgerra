# Ledgerra: Android (Capacitor) + iPhone/iPad (PWA)

โค้ดแอปมีไฟล์เดียวคือ `src/ledgerra.html` ใช้สร้างทั้ง 2 แบบ

| ใช้กับ | คำสั่ง | ได้อะไร |
| --- | --- | --- |
| Android | `npm run android:prepare` แล้วสร้าง APK | แอปที่ไฟล์ทั้งหมดอยู่ใน APK ใช้ออฟไลน์ได้ |
| iPhone/iPad | `npm run build:pwa` | โฟลเดอร์ `dist/pwa` ลากไปวางที่ Netlify Drop เหมือนเดิม |

## 4 อย่างที่ห้ามเปลี่ยน (ไม่งั้นอัปเดตทับไม่ได้ หรือข้อมูลเหมือนหายไป)

1. `appId` ใน `capacitor.config.json` = `app.ledgerra`
2. `server.androidScheme` = `https` และ `server.hostname` = `localhost` (ข้อมูลผูกกับที่อยู่นี้)
3. กุญแจ `ledgerra-release.jks` และ alias `ledgerra` ใช้ชุดเดิมตลอด
4. `version` ใน `package.json` ต้องเพิ่มทุกครั้งที่อัปเดต (1.0.0 → 1.0.1 → 1.1.0 …)

## สร้าง APK (เลือก 1 ทาง)

### ทาง A: GitHub Actions (ไม่ต้องลงโปรแกรม ใช้เบราว์เซอร์ได้)
1. สมัคร GitHub แล้วสร้าง repository แบบ **Private**
2. อัปโหลดไฟล์ทั้งโฟลเดอร์นี้ (keystore อยู่แยกอีกชุด ไม่ได้อยู่ในโฟลเดอร์นี้)
   - ถ้าโฟลเดอร์ `.github` ไม่ขึ้นไปด้วย (Mac และ iPad ซ่อนไฟล์ที่ชื่อขึ้นต้นด้วยจุด) ให้กด Add file → Create new file ตั้งชื่อ `.github/workflows/android.yml` แล้ววางข้อความจากไฟล์นั้นลงไป
   - อย่าอัปโหลด keystore ขึ้น repository เด็ดขาด ใส่เป็น Secret ตามข้อ 3 เท่านั้น
3. Settings → Secrets and variables → Actions → New repository secret สร้าง 2 อัน
   - `LEDGERRA_KEYSTORE_B64` = ข้อความทั้งหมดในไฟล์ `ledgerra-release.jks.base64.txt`
   - `LEDGERRA_KEYSTORE_PASSWORD` = รหัสผ่าน keystore
4. แท็บ Actions → **Build Android APK** → Run workflow
5. เสร็จแล้ว (ประมาณ 5–10 นาที) กดดาวน์โหลด `ledgerra-apk` จะได้ไฟล์ zip ที่มี APK อยู่ข้างใน

### ทาง B: Android Studio บนคอม (Windows/Mac)
1. ติดตั้ง Node.js 22 LTS และ Android Studio
2. เปิด Terminal ในโฟลเดอร์นี้ แล้วรัน `npm install` และ `npm run android:prepare`
3. เปิดโฟลเดอร์ `android` ด้วย Android Studio
4. Build → Generate Signed App Bundle or APK → APK → เลือก `ledgerra-release.jks`, alias `ledgerra`, ใส่รหัสผ่าน → release

### ทาง C: ให้ Claude สร้างให้ในแชตใหม่
เปิดสิทธิ์ติดตั้งแพ็กเกจที่ claude.ai → Settings → Capabilities (npm, Google Maven, Maven Central, Gradle) แล้วเริ่มแชตใหม่พร้อมแนบโฟลเดอร์นี้และ keystore
ทางนี้ต้องส่ง keystore เข้าแชต ถ้าเน้นความเป็นส่วนตัวสูงสุด ให้ใช้ทาง A หรือ B

## ติดตั้งบนมือถือ Android
1. ส่งไฟล์ APK เข้ามือถือ (เช่น Google Drive หรือสาย USB) แล้วแตะเปิด
2. ถ้าขึ้นว่าไม่อนุญาต ให้เปิด "ติดตั้งแอปที่ไม่รู้จัก" ให้แอปที่ใช้เปิดไฟล์ (Files หรือ Chrome)
3. ถ้า Play Protect เตือนว่าไม่รู้จักผู้พัฒนา กด "ติดตั้งต่อไป" (เพราะไม่ได้ผ่าน Play Store)

## อัปเดตโดยข้อมูลไม่หาย
1. วางไฟล์ `ledgerra.html` ใหม่ทับ `src/ledgerra.html`
2. เพิ่ม `version` ใน `package.json`
3. สร้าง APK ใหม่ด้วยกุญแจเดิม แล้วติดตั้งทับได้เลย ข้อมูลอยู่ครบ
4. **ห้ามลบแอปก่อนอัปเดต** การลบแอปทำให้ข้อมูลในเครื่องหาย (สำรองเป็นไฟล์ไว้ก่อนเสมอ)

## ความเป็นส่วนตัว
- ข้อมูลการเงินเก็บในเครื่องแบบเข้ารหัส ไม่ส่งไปที่ไหน ไม่มีตัวติดตามหรือ analytics
- ปิดการสำรองอัตโนมัติขึ้นคลาวด์ของ Android (`allowBackup="false"`) ข้อมูลจะไม่ถูกส่งขึ้น Google Drive เอง
- ถ้าสร้าง APK ตอนมีเน็ต ฟอนต์และตัวอ่านสลิปจะถูกใส่ไว้ใน APK ด้วย แอปจึงไม่ต้องติดต่อเซิร์ฟเวอร์ภายนอกเลย
- รูปสลิปอ่านในเครื่อง ไม่ถูกส่งออกไป
- สิทธิ์ที่ขอมีแค่ INTERNET (สำหรับระบบซิงก์ในอนาคต) ไม่ขอสิทธิ์กล้อง ตำแหน่ง หรือรายชื่อติดต่อ
